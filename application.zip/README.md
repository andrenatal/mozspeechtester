voicedialer-gaia
================

Voice Dialer for Gaia FxOS using  Web Speech API

https://developer.mozilla.org/en-US/docs/Web/API/Contacts_API

https://developer.mozilla.org/en-US/docs/Web/API/Telephony
